/** Automatically generated file. DO NOT MODIFY */
package com.wa.animato;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}