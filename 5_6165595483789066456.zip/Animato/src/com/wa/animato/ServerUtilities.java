package com.wa.animato;

import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.provider.Settings.Secure;
import android.util.Log;
import android.widget.Toast;

import com.animato.common.ConstantValue;
import com.animato.common.HttpRestClient;
import com.animato.common.Reg;
import com.animato.common.UsefullData;
import com.animato.database.TableRegId;
import com.google.android.gcm.GCMRegistrar;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

public final class ServerUtilities {
	private static final int MAX_ATTEMPTS = 5;
	private static final int BACKOFF_MILLI_SECONDS = 2000;
	private static final Random random = new Random();

	private static TableRegId tableRegId;

	/**
	 * Register this account/device pair within the server.
	 * 
	 */
	public static void register(final Context context, final String regId) {
		// Log.e("abc", "registering device (regId = " + regId + ")");

		tableRegId = new TableRegId(context);

		if (tableRegId.isRecordExist()) {
			// do nothing
		} else {
			Reg reg = new Reg();
			reg.id = "1";
			reg.regId = regId;
			reg.status = "0";
			tableRegId.add(reg);

			if (regId.length() == 0) {

			} else {
				callSubmitGCMIDApi(regId,  context);
			}
		}

		long backoff = BACKOFF_MILLI_SECONDS + random.nextInt(1000);
		// Once GCM returns a registration id, we need to register on our server
		// As the server might be down, we will retry it a couple
		// times.
		for (int i = 1; i <= MAX_ATTEMPTS; i++) {

			try {
				// Toast.makeText(context, "===" + regId,
				// Toast.LENGTH_LONG).show();
				GCMRegistrar.setRegisteredOnServer(context, true);

				return;
			} catch (Exception e) {

				Log.e("ServerUtilities", "Failed to register on attempt " + i
						+ ":" + e);
				if (i == MAX_ATTEMPTS) {
					break;
				}
				try {
					Log.d("ServerUtilities", "Sleeping for " + backoff
							+ " ms before retry");
					Thread.sleep(backoff);
				} catch (InterruptedException e1) {
					// Activity finished before we complete - exit.
					Log.d("ServerUtilities",
							"Thread interrupted: abort remaining retries!");
					Thread.currentThread().interrupt();
					return;
				}
				// increase backoff exponentially
				backoff *= 2;
			}
		}
	}

	/**
	 * Unregister this account/device pair within the server.
	 */
	static void unregister(final Context context, final String regId) {
		Log.i("ServerUtilities", "unregistering device (regId = " + regId + ")");

		try {
			GCMRegistrar.setRegisteredOnServer(context, false);

		} catch (Exception e) {
			Log.e("ServerUtilities", "Unregister on attempt " + e);
		}
	}

	/**
	 * 
	 * Api to send GCM regID on news
	 * 
	 */
	// ======================================//
	private static void callSubmitGCMIDApi(String regId, Context context) {

		Log.e("abc", "=====11111111======" + regId);
		RequestParams params = new RequestParams();
		
		String device_id = Secure.getString(context.getContentResolver(),
                Secure.ANDROID_ID); 
		
		Log.e("abc", "=================" + device_id);

		params.put("regid", regId);
		params.put("device_id", device_id);

		HttpRestClient.post(ConstantValue.REGISTER_GCM_URL, params,
				new AsyncHttpResponseHandler() {
					@Override
					public void onStart() {
						super.onStart();
						/*
						 * objUsefullData.showProgress(
						 * getString(R.string.msg_please_wait).toString(), "");
						 */
					}

					@Override
					public void onSuccess(String response) {
						UsefullData.Log("" + response);
						try {
							JSONObject serverResp = new JSONObject(response);
							int success = serverResp.getInt("success");
							if (success == 1) {
								Log.e("abc",
										"+++++++++++++++ GCM Registed ++++++++++++");
							} else {
								Log.e("abc",
										"+++++++++++++++ GCM Not Registed ++++++++++++");
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					@Override
					public void onFinish() {
						// TODO Auto-generated method stub
						super.onFinish();
						/* objUsefullData.dismissProgress(); */
					}
				});
	}

}