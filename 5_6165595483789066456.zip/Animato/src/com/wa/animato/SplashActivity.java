package com.wa.animato;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.animato.common.HttpRestClient;
import com.animato.common.UsefullData;
import com.animato.home.HomeTabActivty;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

public class SplashActivity extends BaseActivity {

	private GoogleCloudMessaging gcm;
	private String regid;
	private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		//createHashKey();
		if (!objUsefullData.isNetworkConnected())
			objUsefullData.showMsgOnUI("Please check you Internet connnection");

		registerDevice();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
	}


	// ============================================//
	private void registerDevice() {
		if (checkPlayServices()) {
			gcm = GoogleCloudMessaging.getInstance(this);

			if (!objSaveData.isExist(KEY_REGI_ID)) {
				UsefullData.Log("Start");
				registerInBackground();
			} else {
				UsefullData.Log("All ready reg id exist."+ objSaveData.get(KEY_REGI_ID));
				callUpdateRegiApi();
			}
		} else {
			UsefullData.Log("No valid Google Play Services APK found.");
		}

	}

	// ============================================//

	private void registerInBackground() {

		new Thread() {
			public void run() {
				String msg = "";

				if (gcm == null) {
					gcm = GoogleCloudMessaging.getInstance(SplashActivity.this);
				}
				try {
					UsefullData.Log("Sender :" + SENDER_ID);
					regid = gcm.register(SENDER_ID);
					msg = "Device registered, registration ID=" + regid;
					//UsefullData.Log("reg Id :" + msg);
					objSaveData.save(KEY_REGI_ID, regid);
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					runOnUiThread(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							callUpdateRegiApi();
						}
					});
					
				}
			}

		}.start();

	}

	// ============================================//
	private boolean checkPlayServices() {
		int resultCode = GooglePlayServicesUtil
				.isGooglePlayServicesAvailable(this);
		if (resultCode != ConnectionResult.SUCCESS) {
			if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
				GooglePlayServicesUtil.getErrorDialog(resultCode, this,
						PLAY_SERVICES_RESOLUTION_REQUEST).show();
			} else {
				Log.i("tt", "This device is not supported.");
				finish();
			}
			return false;
		}
		return true;
	}

	// ======================================//
	private void callUpdateRegiApi() {

		RequestParams params = new RequestParams();
		// device_id=123&reg_id=1231k3213kj21341
		params.put("reg_id", objSaveData.get(KEY_REGI_ID));

		HttpRestClient.post(REGISTER_GCM_URL, params,
				new AsyncHttpResponseHandler() {
					@Override
					public void onStart() {
						// TODO Auto-generated method stub
						super.onStart();
						objUsefullData.showProgress(
								getString(R.string.msg_please_wait).toString(),
								"");
					}

					@Override
					public void onSuccess(String response) {
						UsefullData.Log("" + response);

						try {
							JSONObject serverResp = new JSONObject(response);
							int success = serverResp.getInt("success");
							if (success == 1) {
								//objUsefullData.showMsgOnUI("Comment succesfully uploaded.");

							} else {
								/*objUsefullData
										.showMsgOnUI("Sorry! your comment did not submitted. Please try again");*/
							}

						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();

						}

					}

					@Override
					public void onFinish() {
						// TODO Auto-generated method stub
						super.onFinish();
						objUsefullData.dismissProgress();
						moveNextAct();
					}
				});
	}

	// ================================//
	private void moveNextAct() {
		startActivity(new Intent(SplashActivity.this, HomeTabActivty.class));
		finish();
	}

}
