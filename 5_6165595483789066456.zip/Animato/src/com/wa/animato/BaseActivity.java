package com.wa.animato;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import com.animato.common.ConstantValue;
import com.animato.common.SaveData;
import com.animato.common.UsefullData;

public class BaseActivity extends FragmentActivity implements ConstantValue {
   
	public UsefullData objUsefullData;
	
	public SaveData objSaveData;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        objUsefullData = new UsefullData(this);
        objSaveData = new SaveData(this);
    }
}