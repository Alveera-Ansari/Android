package com.animato.database;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.animato.common.Reg;
import com.animato.common.UsefullData;

public class TableRegId extends BaseDataBaseTable {

	public static String TABLE_NAME = "reg";
	public static String KEY_ID = "id";
	public static String KEY_REGID = "regid";
	public static String KEY_STATUS = "status";
	
	public static String CREATE_ITEM_TABLE = "CREATE TABLE " + TABLE_NAME + "("
			+ KEY_ID + " TEXT PRIMARY KEY," + KEY_REGID + " TEXT," + KEY_STATUS + " TEXT " + ")";

	public static String DROP_ITEM_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME;

	//=============================================//
	public TableRegId(Context c) {
		super(c);
	}

	//=============================================//
	public void add(Reg _item) {
		ContentValues values = new ContentValues();
		values.put(KEY_ID, _item.id);
		values.put(KEY_REGID, _item.regId);
		values.put(KEY_STATUS, _item.status);
		long i = insertValue(TABLE_NAME, values);
		if (i != -1) {
			UsefullData.Log("Data inserted succesfully");
		}
	}
	
	//===============================================//
	public void updateLoginRecord(String id, String status) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_STATUS, status);
		
		Log.v("", "@@@@@@@@@@ Login record updated");
		db.update(TABLE_NAME, values, KEY_ID + " = ?",
				new String[] { String.valueOf(id) });
		
		db.close();
	}

	//==============================================//
	public void delete(String id) {
		SQLiteDatabase db = this.getReadableDatabase();
		db.execSQL("delete from " + TABLE_NAME + " where " + KEY_ID + " = '"
				+ id + "'");
		UsefullData.Log("Data deleted succesfully");
	}

	//=============================================//
	public ArrayList<Reg> getAllDataFromQuery(String whereClause) {
		SQLiteDatabase db = this.getReadableDatabase();
		ArrayList<Reg> itemDetail = new ArrayList<Reg>();
		String sql = "select * from " + TABLE_NAME;
		if (whereClause != null) {
			// || whereClause != ""
			sql = sql + " where " + whereClause;
		}
		Cursor c = db.rawQuery(sql, null);
		if (c != null) {
			if (c.moveToFirst()) {
				itemDetail = loadData(c);
			}
		}
		db.close();
		return itemDetail;
	}

	//=================================================//
	public ArrayList<Reg> loadData(Cursor c) {
		ArrayList<Reg> itemDetail = new ArrayList<Reg>();
		do {
			Reg _item = new Reg();
			_item.regId = c.getString(c.getColumnIndex(KEY_REGID));
			_item.status = c.getString(c.getColumnIndex(KEY_STATUS));
			itemDetail.add(_item);
		} while (c.moveToNext());
		c.close();
		return itemDetail;
	}

	//=================================================//
	public boolean isRecordExist() {
		boolean isExist = false;
		SQLiteDatabase db = getReadableDatabase();
		String sql = "select * from " + TABLE_NAME; // "select * from " +
													// TABLE_NAME + " where " +
													// KEY_ID + " ='" + id +
													// "'";
		Cursor c = db.rawQuery(sql, null);
		if (c.getCount() > 0) {
			isExist = true;
		} else {
			isExist = false;
		}
		c.close();
		db.close();
		return isExist;
	}

	//===========================================//
	public boolean isRecordExistPerticularly(String id) {
		boolean isExist = false;
		SQLiteDatabase db = getReadableDatabase();
		String sql = "select * from " + TABLE_NAME + " where " + KEY_ID + " ='"
				+ id + "'";
		Cursor c = db.rawQuery(sql, null);
		if (c.getCount() > 0) {
			isExist = true;
		} else {
			isExist = false;
		}
		c.close();
		db.close();
		return isExist;
	}
}
