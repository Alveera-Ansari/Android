package com.animato.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class BaseDataBaseTable extends DataBaseHelper {

	private static String DB_NAME = "animato.sqlite3";
	private static int DB_VERSION = 1;

	DataBaseHelper dbHelper;

	public BaseDataBaseTable(Context c) {
		super(c, DB_NAME, null, DB_VERSION);
	}

	// =========================================================//

	public long insertValue(String tableName, ContentValues values) {
		SQLiteDatabase db = getWritableDatabase();
		long i = db.insert(tableName, null, values);
		db.close();
		return i;
	}

	// =========================================================//

	public void deleteTable(String tableName) {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(tableName, null, null);
		db.close();
	}

}
