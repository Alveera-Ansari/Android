package com.animato.videosreview;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.animato.adapter.MyVediosAdapter;
import com.animato.common.BaseFragment;
import com.animato.common.HttpRestClient;
import com.animato.common.MyVedios;
import com.animato.common.UsefullData;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.wa.animato.R;

public class VideoReviewFragment extends BaseFragment {

	/**
	 * Provide names to variables
	 */

	private ListView vedioLV;
	private TextView reslutTV;
	private MyVediosAdapter objAdapter;
	private ImageButton ibVFacebook;
	private Button ibVShop;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		/**
		 * Initialization of variables
		 */
		View view = inflater.inflate(R.layout.fragment_video_review, container,
				false);
		objAdapter = new MyVediosAdapter(getActivity());
		reslutTV = (TextView) view.findViewById(R.id.resultTV);
		vedioLV = (ListView) view.findViewById(R.id.videoLV);
		ibVFacebook = (ImageButton) view.findViewById(R.id.ibVFacebook);
		ibVShop = (Button) view.findViewById(R.id.ibVShop);

		vedioLV.setAdapter(objAdapter);

		// ================================================//
		ibVFacebook.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");
			}
		});
		/**
		 * Setting click listener on ListView to go to details page
		 * 
		 **/
		vedioLV.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				Fragment fragment = VideoDetailFragment.newInstances(objAdapter
						.getItem(position));
				FragmentTransaction gurudwarafragmentTransaction = getFragmentManager()
						.beginTransaction();
				gurudwarafragmentTransaction.add(R.id.realtabcontent, fragment);
				gurudwarafragmentTransaction.addToBackStack(null);
				gurudwarafragmentTransaction.commit();
			}
		});

		ibVShop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://animato.com.au/store");
			}
		});

		callVideoListApi();
		return view;
	}

	/**
	 * Fetching and parsing video data from api
	 * 
	 */
	// ======================================//
	private void callVideoListApi() {
		HttpRestClient.get(VEDIOS_URL, new AsyncHttpResponseHandler() {
			@Override
			public void onStart() {
				super.onStart();
				objUsefullData.showProgress(getString(R.string.msg_please_wait)
						.toString(), "");
			}

			@Override
			public void onSuccess(String response) {
				UsefullData.Log("" + response);
				try {
					if (response.length() > 0) {
						JSONObject jsonObject = new JSONObject(response);
						String success = jsonObject.getString("success");

						if (success.equals("1")) {
							JSONArray serverResp = jsonObject
									.getJSONArray("data");
							for (int i = 0; i < serverResp.length(); i++) {

								JSONObject dataJson = serverResp
										.getJSONObject(i);
								String video_title = dataJson
										.getString("video_title");
								String video_thumb = dataJson
										.getString("thumb_url");
								String youtube_url = dataJson
										.getString("video_url");
								String review = dataJson.getString("review");

								objAdapter.addItem(new MyVedios(video_title,
										video_thumb, youtube_url, review));
							}
						}
					} else {

					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void onFinish() {
				// TODO Auto-generated method stub
				super.onFinish();
				objUsefullData.dismissProgress();
				displayDataInListView();
			}
		});
	}

	/**
	 * Setting views
	 * 
	 */
	// =================================================//
	private void displayDataInListView() {
		if (objAdapter.getCount() > 0) {
			objAdapter.notifyDataSetChanged();
			vedioLV.setVisibility(View.VISIBLE);
			reslutTV.setVisibility(View.INVISIBLE);
		} else {
			vedioLV.setVisibility(View.INVISIBLE);
			reslutTV.setVisibility(View.VISIBLE);
		}

	}
}
