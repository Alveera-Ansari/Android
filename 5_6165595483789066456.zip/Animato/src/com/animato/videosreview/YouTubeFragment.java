package com.animato.videosreview;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import com.animato.common.BaseFragment;
import com.animato.common.MyVedios;
import com.wa.animato.R;

public class YouTubeFragment extends BaseFragment {

	
	/**
	 * Provide names to variables
	 */
	private static final String KEY_STORE = "video_keys";
	private MyVedios videos;
	private WebView webview;

	

	/**
	 * creating Instance for fragment
	 */
	public static Fragment newInstances(MyVedios videos) {
		Fragment fragment = new YouTubeFragment();
		Bundle b = new Bundle();
		b.putSerializable(KEY_STORE, videos);
		fragment.setArguments(b);
		return fragment;
	}


	/**
	 * On create method for fragment
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		videos = (MyVedios) getArguments().getSerializable(KEY_STORE);
	}
	
	
	/**
	 * on create view method for fragment
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.youtube_layout, container, false);

		
		/**
		 *
		 * Creating webview to play you tube video
		 *
		 */
		
		webview = (WebView) view.findViewById(R.id.webView1);

		webview.getSettings().setJavaScriptEnabled(true);

		webview.loadUrl(videos.getYoutubeUrl());

		return view;
	}
}
