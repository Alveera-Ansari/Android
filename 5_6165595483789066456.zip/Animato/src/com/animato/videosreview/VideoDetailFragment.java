package com.animato.videosreview;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.animato.common.BaseFragment;
import com.animato.common.MyVedios;
import com.wa.animato.R;

public class VideoDetailFragment extends BaseFragment {

	/**
	 * Provide names to variables
	 */

	private MyVedios videos;
	private ImageView videoimage;
	private TextView reviewdetailTV;
	private TextView tvTitle;
	private ImageButton ibVDFacebook;
	private static final String KEY_STORE = "video_keys";
	private Button ibVDShop;

	/**
	 * creating Instance for fragment
	 */
	public static Fragment newInstances(MyVedios vedios) {
		Fragment fragment = new VideoDetailFragment();
		Bundle b = new Bundle();
		b.putSerializable(KEY_STORE, vedios);
		fragment.setArguments(b);
		return fragment;
	}

	/**
	 * On create method for fragment
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		videos = (MyVedios) getArguments().getSerializable(KEY_STORE);
	}

	/**
	 * on create view method for fragment
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.video_detail_fragment, container,
				false);

		/**
		 * Initialization of variables
		 */
		reviewdetailTV = (TextView) view.findViewById(R.id.reviewdetailTV);
		videoimage = (ImageView) view.findViewById(R.id.videoImage);
		tvTitle = (TextView) view.findViewById(R.id.tvTitle);
		ibVDFacebook = (ImageButton) view.findViewById(R.id.ibVDFacebook);
		ibVDShop  = (Button)view.findViewById(R.id.ibVDShop);

		/**
		 * Hitting url to play video in You tube
		 */

		videoimage.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Uri uri = Uri.parse("" + videos.getYoutubeUrl());
				Intent intent = new Intent(Intent.ACTION_VIEW, uri);
				startActivity(intent);
			}
		});

		// ================================================//
		ibVDFacebook.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");
			}
		});
		
		ibVDShop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://animato.com.au/store");
			}
		});

		updateAllData();
		return view;

	}

	private void updateAllData() {
		if (videos != null) {
			reviewdetailTV.setText("" + videos.getReviews());
			tvTitle.setText("" + videos.getVedioName());

			// .setText("" + videos.getReviews());
			objImageLoader.DisplayImage(videos.getVideoThumb(), videoimage);
		}
	}
}
