package com.animato.bookreview;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;

import com.animato.common.BaseFragment;
import com.animato.common.MyBooks;
import com.wa.animato.R;

public class NewBookDetailFragment extends BaseFragment {

	private static final String KEY_STORE = "book_keys";
	private MyBooks books;
	private WebView webview;
	private ImageButton ibNBDFacebook;
	private Button ibNBDShop;
	
	public static Fragment newInstances(MyBooks books) {
		Fragment fragment = new NewBookDetailFragment();
		Bundle b = new Bundle();
		b.putSerializable(KEY_STORE, books);
		fragment.setArguments(b);
		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		books = (MyBooks) getArguments().getSerializable(KEY_STORE);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.new_book_detail_fragment,
				container, false);
		webview = (WebView) view.findViewById(R.id.webView1);
		ibNBDFacebook = (ImageButton) view.findViewById(R.id.ibNBDFacebook);
		ibNBDShop     = (Button)view.findViewById(R.id.ibNBDShop);
		
		webview.getSettings().setJavaScriptEnabled(true);
		webview.loadUrl(books.getBookUrl());
		
		this.webview.setWebViewClient(new WebViewClient(){
		    @Override
		    public boolean shouldOverrideUrlLoading(WebView view, String url){
		      view.loadUrl(url);
		      return true;
		    }
		});
		
		
		ibNBDShop.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://animato.com.au/store");
			}
		});
		
		
		//================================================//
		ibNBDFacebook.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");
			}
		});
		
		return view;

	}

}