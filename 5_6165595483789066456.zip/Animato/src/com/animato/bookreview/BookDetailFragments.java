package com.animato.bookreview;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.animato.common.BaseFragment;
import com.animato.common.MyBooks;
import com.wa.animato.R;

public class BookDetailFragments extends BaseFragment {

	/**
	 * Provide names to variables
	 */
	private TextView nameTV, authorTV, reviewTV;
	private ImageView bookImageView;
	private Button purchaseBtn;
	private static final String KEY_STORE = "book_keys";
	public MyBooks books;
	private ImageButton ibBDFacebook;
	
	private Button ibBDShop;

	/**
	 * creating Instance for fragment
	 */
	public static Fragment newInstances(MyBooks books) {
		Fragment fragment = new BookDetailFragments();
		Bundle b = new Bundle();
		b.putSerializable(KEY_STORE, books);
		fragment.setArguments(b);
		return fragment;
	}

	/**
	 * On create method for fragment
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		books = (MyBooks) getArguments().getSerializable(KEY_STORE);
	}

	/**
	 * on create view method for fragment
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		final View view = inflater.inflate(R.layout.fragment_book_detail,
				container, false);

		/**
		 * Initialization of variables
		 */
		nameTV = (TextView) view.findViewById(R.id.nameTV);
		authorTV = (TextView) view.findViewById(R.id.authorTV);
		reviewTV = (TextView) view.findViewById(R.id.reviewTV);
		bookImageView = (ImageView) view.findViewById(R.id.bookImage);
		purchaseBtn = (Button) view.findViewById(R.id.purchaseBtn);
		ibBDFacebook = (ImageButton) view.findViewById(R.id.ibBDFacebook);
		objImageLoader.DisplayImage(books.getBookIconUrl(), bookImageView);
		ibBDShop = (Button)view.findViewById(R.id.ibBDShop);

		/**
		 * on click button to go to details page
		 */
		purchaseBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Fragment fragment = NewBookDetailFragment.newInstances(books);
				FragmentTransaction gurudwarafragmentTransaction = getFragmentManager()
						.beginTransaction();
				gurudwarafragmentTransaction.add(R.id.realtabcontent, fragment);
				gurudwarafragmentTransaction.addToBackStack(null);
				gurudwarafragmentTransaction.commit();
			}
		});
		
		
        /**
		 * 
		 * Social sites buttons with their clicks
		 * 
		 */
		
		  
		ibBDShop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://animato.com.au/store");
			}
		});
		
		//================================================//
		ibBDFacebook.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");
			}
		});
		
		/**
		 * on click image to go to details page
		 */
		bookImageView.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				Fragment fragment = NewBookDetailFragment.newInstances(books);
				FragmentTransaction gurudwarafragmentTransaction = getFragmentManager()
						.beginTransaction();
				gurudwarafragmentTransaction.add(R.id.realtabcontent, fragment);
				gurudwarafragmentTransaction.addToBackStack(null);
				gurudwarafragmentTransaction.commit();
			}
		});

		updateAllData();
		return view;
	}

	// ======================================//
	private void updateAllData() {
		if (books != null) {
			nameTV.setText("" + books.getBookName());
			authorTV.setText("" + books.getAuthName());
			reviewTV.setText("" + books.getReviews());

			objImageLoader.DisplayImage(books.getBookIconUrl(), bookImageView);
		}
	}
}
