package com.animato.bookreview;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.animato.adapter.MyBooksAdapter;
import com.animato.common.BaseFragment;
import com.animato.common.HttpRestClient;
import com.animato.common.MyBooks;
import com.animato.common.UsefullData;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.wa.animato.R;

public class BookReviewFragment extends BaseFragment {

	/**
	 * Provide names to variables
	 */
	private ListView bookLV;
	private TextView reslutTV;
	private MyBooksAdapter objAdapter;
	private ImageButton ibBFacebook;
	private Button ibBShop;

	/**
	 * on create view method for fragment
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_book_review, container,
				false);

		/**
		 * Initialization of variables
		 */
		objAdapter = new MyBooksAdapter(getActivity());
		reslutTV = (TextView) view.findViewById(R.id.resultTV);
		bookLV = (ListView) view.findViewById(R.id.bookLV);
		ibBFacebook = (ImageButton) view.findViewById(R.id.ibBFacebook);
		ibBShop = (Button) view.findViewById(R.id.ibBShop);

		bookLV.setAdapter(objAdapter);

		/**
		 * Click on list view to go to details page
		 */
		bookLV.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Fragment fragment = BookDetailFragments.newInstances(objAdapter
						.getItem(position));
				FragmentTransaction gurudwarafragmentTransaction = getFragmentManager()
						.beginTransaction();
				gurudwarafragmentTransaction.add(R.id.realtabcontent, fragment);
				gurudwarafragmentTransaction.addToBackStack(null);
				gurudwarafragmentTransaction.commit();
			}
		});

		/**
		 * 
		 * Social sites buttons with their clicks
		 * 
		 */

		// ================================================//
		ibBFacebook.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");
			}
		});

		ibBShop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://animato.com.au/store");
			}
		});

		callBookListApi();
		return view;
	}

	/**
	 * 
	 * Fetch and parse product data from api
	 */
	// ======================================//
	private void callBookListApi() {
		HttpRestClient.get(BOOK_URL, new AsyncHttpResponseHandler() {
			@Override
			public void onStart() {
				super.onStart();
				objUsefullData.showProgress(getString(R.string.msg_please_wait)
						.toString(), "");
			}

			@Override
			public void onSuccess(String response) {
				UsefullData.Log("" + response);
				try {
					JSONObject serverResp = new JSONObject(response);

					JSONArray jsonArray = serverResp.getJSONArray("data");

					for (int i = 0; i < jsonArray.length(); i++) {

						JSONObject dataJson = jsonArray.getJSONObject(i);

						String book_name = dataJson.getString("title");
						String auth_name = dataJson.getString("Publisher_name");
						String book_icon = dataJson.getString("img_url");

						String url = dataJson.getString("Publisher_url");
						String review = dataJson.getString("content");

						objAdapter.addItem(new MyBooks(book_name, auth_name,
								book_icon, url, review));
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			@Override
			public void onFinish() {
				super.onFinish();
				objUsefullData.dismissProgress();
				displayDataInListView();
			}
		});
	}

	// =================================================//
	private void displayDataInListView() {
		if (objAdapter.getCount() > 0) {
			objAdapter.notifyDataSetChanged();
			bookLV.setVisibility(View.VISIBLE);
			reslutTV.setVisibility(View.INVISIBLE);
		} else {
			bookLV.setVisibility(View.INVISIBLE);
			reslutTV.setVisibility(View.VISIBLE);
		}
	}
}
