package com.animato.quotes;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.animato.common.BaseFragment;
import com.animato.common.HttpRestClient;
import com.animato.common.UsefullData;
import com.animato.database.TableRegId;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.wa.animato.R;

public class QuotesFragments extends BaseFragment {

	/**
	 * Provide names to variables
	 */
	private EditText commentED;
	private TextView quoteTV;
	private Button submitBtn, publishBtn;
	private Button btnFbLike;
	private Button btnTwitter;
	private Button btnGoogle;
	private TextView quoteTVTitle;
	private String quote_id;
	private ImageButton ibQFacebook;

	//private TableRegId tableRegId;
	
	private Button ibQShop;
	
	private LinearLayout  llQuotes;
	private LinearLayout  llFirst;

	/**
	 * onCreateView method for fragment
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater
				.inflate(R.layout.fragment_quotes, container, false);
		
		/**
		 * Initialization of variables
		 */

		//tableRegId = new TableRegId(getActivity());
		commentED = (EditText) view.findViewById(R.id.commentED);
		quoteTV = (TextView) view.findViewById(R.id.quoteTV);
		submitBtn = (Button) view.findViewById(R.id.submitBtn);
		publishBtn = (Button) view.findViewById(R.id.publishedBtn);
		quoteTVTitle = (TextView) view.findViewById(R.id.quoteTVTitle);
		btnFbLike = (Button) view.findViewById(R.id.btnFbLike);
		btnTwitter = (Button) view.findViewById(R.id.btnTwitter);
		btnGoogle = (Button) view.findViewById(R.id.btnGoogle);
		ibQFacebook = (ImageButton) view.findViewById(R.id.ibQFacebook);
		
		llQuotes   = (LinearLayout)view.findViewById(R.id.llQuotes);
		llFirst    =  (LinearLayout)view.findViewById(R.id.llFirst);
		
		ibQShop = (Button)view.findViewById(R.id.ibQShop);
		commentED.clearFocus();
		// ===============================================//

		/**
		 * 
		 * Social sites buttons with their clicks
		 * 
		 */

		// ================================================//

		ibQFacebook.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				/*WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");*/
				openWebView("http://facebook.com/animatostrings");
			}
		});
		
		
		ibQShop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				/*WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://animato.com.au/store");*/
				openWebView("http://animato.com.au/store");
				
			}
		});

		// ===============================================//

		btnFbLike.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				/*WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");*/
				openWebView("http://facebook.com/animatostrings");
			}
		});

		// ===============================================//
		btnTwitter.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-gWenerated method stub
				/*WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("https://twitter.com/animatostrings");*/
				
				openWebView("https://twitter.com/animatostrings");
			}
		});

		// ===============================================//
		btnGoogle.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				/*WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("https://plus.google.com/u/1/b/115888451564195471750/115888451564195471750/posts");*/
				openWebView("https://plus.google.com/u/1/b/115888451564195471750/115888451564195471750/posts");
			}
		});

		// ==============================================//
		submitBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				if (checkValidation()) {
					callSubmitCommentApi();
				}
			}
		});

		// ==============================================//
		publishBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				String url = "http://animato.newsupdate.net.au/news/";
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse(url));
				startActivity(i);
				
			/*	Fragment fragment = PublishCommentFragments.newInstances();
				FragmentTransaction gurudwarafragmentTransaction = getFragmentManager()
						.beginTransaction();
				gurudwarafragmentTransaction.add(R.id.realtabcontent, fragment);
				gurudwarafragmentTransaction.addToBackStack(null);
				gurudwarafragmentTransaction.commit();*/
			}
		});
		
		llQuotes.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyboard();
			}
		});
		
		llFirst.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyboard();
			}
		});

		callQuotesApi();
		return view;
	}
	
	private void hideKeyboard() {
		InputMethodManager inputManager = (InputMethodManager) getActivity()
				.getSystemService(Context.INPUT_METHOD_SERVICE);

		// check if no view has focus:
		View view = getActivity().getCurrentFocus();
		if (view != null) {
			inputManager.hideSoftInputFromWindow(view.getWindowToken(),
					InputMethodManager.HIDE_NOT_ALWAYS);
		}
	}
	  
	/**
	 * 
	 * validations on fields
	 * 
	 */
	// ===========================================//
	private boolean checkValidation() {

		if (objValidation.checkEmpty(commentED, getString(R.string.comments)
				.toString())) {
			return false;
		}
		return true;
	}

	/**
	 * 
	 * Fetching and parsing News data from api
	 * 
	 */
	// ======================================//
	private void callQuotesApi() {
		HttpRestClient.get(NEWS_URL, new AsyncHttpResponseHandler() {
			@Override
			public void onStart() {
				super.onStart();
				objUsefullData.showProgress(getString(R.string.msg_please_wait)
						.toString(), "");
			}

			@Override
			public void onSuccess(String response) {
				UsefullData.Log("" + response);
				try {
					JSONObject serverResp = new JSONObject(response);
					int success = serverResp.getInt("success");
					if (success == 1) {
						JSONArray dataResult = serverResp.getJSONArray("data");
						JSONObject quotesResp = dataResult.getJSONObject(0);
						quoteTVTitle.setText(quotesResp.getString("title"));
						quoteTV.setText("\"" + quotesResp.getString("content")
								+ "\"");
					
						/*quoteTV.setText(Html.fromHtml(quotesResp.getString("content")));
						quoteTV.setMovementMethod(LinkMovementMethod.getInstance());
						*/
						quote_id = quotesResp.getString("id");

					} else {

					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void onFinish() {
				// TODO Auto-generated method stub
				super.onFinish();
				objUsefullData.dismissProgress();
			}
		});
	}

	/**
	 * 
	 * Api to comment on news
	 * 
	 */
	// ======================================//
	private void callSubmitCommentApi() {

		RequestParams params = new RequestParams();
		String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

		params.put("comment_post_ID", quote_id);
		params.put("comment_author", "Animato");
		params.put("comment_content", commentED.getText().toString());
		params.put("comment_date", date);
		params.put("comment_date_gmt", date);

		HttpRestClient.post(COMMENT_URL, params,
				new AsyncHttpResponseHandler() {
					@Override
					public void onStart() {
						super.onStart();
						objUsefullData.showProgress(
								getString(R.string.msg_please_wait).toString(),
								"");
					}

					@Override
					public void onSuccess(String response) {
						UsefullData.Log("" + response);
						try {
							JSONObject serverResp = new JSONObject(response);
							int success = serverResp.getInt("success");
							if (success == 1) {
								commentED.setText("");
								objUsefullData
										.showMsgOnUI("Comment succesfully uploaded.");
							} else {
								objUsefullData
										.showMsgOnUI("Sorry! your comment did not submitted. Please try again");
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					@Override
					public void onFinish() {
						// TODO Auto-generated method stub
						super.onFinish();
						objUsefullData.dismissProgress();
					}
				});
	}
}
