package com.animato.quotes;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;

import com.animato.common.BaseFragment;
import com.wa.animato.R;

public class PublishCommentFragments extends BaseFragment {

	private WebView webview;
	private ImageButton ibCFacebook;
	private Button ibCShop;

	public static Fragment newInstances() {
		Fragment fragment = new PublishCommentFragments();
		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.fragment_publish_comment,
				container, false);

		webview = (WebView) view.findViewById(R.id.webView1);

		ibCFacebook = (ImageButton) view.findViewById(R.id.ibCFacebook);
		ibCShop = (Button) view.findViewById(R.id.ibCShop);

		webview.getSettings().setJavaScriptEnabled(true);

		// loads the WebView completely zoomed out

		// webview.loadUrl("http://nondualitycommunity.org/blog/");

		/**
		 * Old url provided by dietrich for animato app
		 **/
		// webview.loadUrl("http://animato.newsupdate.net.au");

		webview.loadUrl("http://animato.newsupdate.net.au/news/");

		/**
		 * 
		 * Social sites buttons with their clicks
		 * 
		 */

		// ================================================//
		ibCFacebook.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");
			}
		});

		ibCShop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://animato.com.au/store");
			}
		});

		return view;
	}

}
