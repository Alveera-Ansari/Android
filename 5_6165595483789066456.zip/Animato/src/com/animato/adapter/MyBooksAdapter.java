package com.animato.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.animato.common.ConstantValue;
import com.animato.common.MyBooks;
import com.animato.lazyloading.ImageLoader;
import com.wa.animato.R;

public class MyBooksAdapter extends BaseAdapter implements ConstantValue {

	private Context _context;
	private ArrayList<MyBooks> newsList = new ArrayList<MyBooks>();
	private ImageLoader objImageLoader;

	private LayoutInflater inflator;

	public MyBooksAdapter(Context c) {
		_context = c;

		inflator = (LayoutInflater) _context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		objImageLoader = new ImageLoader(_context);
	}

	// ================================//

	public void addItem(MyBooks _item) {
		newsList.add(_item);

	}

	// ================================//

	public void clearItem() {
		newsList.clear();

	}

	// ================================//

	public void setClicklistener(OnClickListener click) {
		// clickListener = click;

	}

	// ================================//
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return newsList.size();
	}

	// ================================//
	@Override
	public MyBooks getItem(int position) {
		// TODO Auto-generated method stub
		return newsList.get(position);
	}

	// ================================//
	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	// ================================//
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		final MyBooks books = getItem(position);
		ViewHolder viewHolder;
		if (convertView == null) {
			viewHolder = new ViewHolder();
			convertView = (LinearLayout) inflator.inflate(
					R.layout.adapter_book_layout, null);
			viewHolder.nameTV = (TextView) convertView
					.findViewById(R.id.nameTV);
			viewHolder.authTV = (TextView) convertView
					.findViewById(R.id.authorTV);
			viewHolder.reviewTV = (TextView) convertView
					.findViewById(R.id.reviewsTV);
			viewHolder.imageView = (ImageView) convertView
					.findViewById(R.id.vedioImage);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}

		viewHolder.nameTV.setText("" + books.getBookName());
		viewHolder.authTV.setText("("+ books.getAuthName()+")");
		viewHolder.reviewTV.setText("" + books.getReviews());

		objImageLoader.DisplayImage(books.getBookIconUrl(),
				viewHolder.imageView);

		return convertView;
	}

	// ================================//
	class ViewHolder {
		TextView nameTV;
		TextView authTV;
		TextView reviewTV;
		ImageView imageView;
	}

}
