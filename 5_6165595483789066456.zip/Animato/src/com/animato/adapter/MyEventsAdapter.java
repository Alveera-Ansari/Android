package com.animato.adapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.animato.common.MyEvents;
import com.animato.common.UsefullData;
import com.animato.events.EventDetailFragment;
import com.wa.animato.R;

public class MyEventsAdapter extends BaseAdapter {

	private Context _context;
	private ArrayList<MyEvents> newsList = new ArrayList<MyEvents>();

	private LayoutInflater inflator;
	private ViewHolder viewHolder;
	private FragmentManager fm;

	public MyEventsAdapter(Context c, FragmentManager fm) {
		_context = c;
		this.fm = fm;
		inflator = (LayoutInflater) _context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	// =============================================//
	public void addItem(MyEvents event) {
		newsList.add(event);

	}
	

	// =============================================//
		public void sortList() {
			
			Collections.sort(newsList, new Comparator<MyEvents>() {
			    @Override
			    public int compare(MyEvents r1, MyEvents r2) {
			        return r1.event_start_date.trim().compareTo(r2.event_start_date.trim());
			    }
			}); 

		}

	// =============================================//
	public void clearItem() {
		newsList.clear();
	}

	@Override
	public int getCount() {
		return newsList.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	// ================================//
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		Log.v("abc", "============" + position);

		if (convertView == null) {
			viewHolder = new ViewHolder();
			convertView = inflator.inflate(R.layout.adapter_event_layout, null);
			viewHolder.tvDateTime = (TextView) convertView
					.findViewById(R.id.tvDateTime);
			viewHolder.tvTitle = (TextView) convertView
					.findViewById(R.id.tvTitle);
			convertView.setTag(viewHolder);

		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}

		final MyEvents events = (MyEvents) newsList.get(position);

		viewHolder.tvDateTime.setText(UsefullData
				.getFormattedDate(events.event_start_date));
		viewHolder.tvTitle.setText(events.event_title);

		convertView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Fragment f = EventDetailFragment.newInstances(events);
				FragmentTransaction ft = fm.beginTransaction();
				ft.add(R.id.rlEventMain, f);
				ft.addToBackStack(null);
				ft.commit();
			}
		});

		return convertView;
	}

	// ================================//
	class ViewHolder {
		TextView tvDateTime;
		TextView tvTitle;
	}

}
