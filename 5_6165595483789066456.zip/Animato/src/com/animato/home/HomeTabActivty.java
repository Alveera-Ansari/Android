package com.animato.home;

import android.os.Bundle;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;

import com.animato.bookreview.BookReviewFragment;
import com.animato.common.UsefullData;
import com.animato.events.EventsFragment;
import com.animato.quotes.QuotesFragments;
import com.animato.videosreview.VideoReviewFragment;
import com.wa.animato.BaseActivity;
import com.wa.animato.R;

public class HomeTabActivty extends BaseActivity {
	private FragmentTabHost mTabHost;

	//private AsyncTask<Void, Void, Void> mRegisterTask;
	//private String regId;
	///private TableRegId tableRegId;

	private int TAB_VIEW[][] = {
			{ R.string.tab_quote, R.drawable.selector_tab_quotes },
			{ R.string.tab_events, R.drawable.selector_tab_events },
			{ R.string.tab_book_review, R.drawable.selector_tab_book },
			{ R.string.tab_videos_review, R.drawable.selector_tab_vedios } };

	private int TAB_HOST_BG[] = { R.drawable.bg_tab_quote,
			R.drawable.bg_tab_event, R.drawable.bg_tab_book,
			R.drawable.bg_tab_video };

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab_home);

		mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);

/*		//GCMRegistrar.checkDevice(this);

		//GCMRegistrar.checkManifest(this);

		registerReceiver(mHandleMessageReceiver,	new IntentFilter("animato_msg"));

		//regId = GCMRegistrar.getRegistrationId(this);

		//tableRegId = new TableRegId(this);

		if (regId.equals("")) {

			Log.e("abc", "=======" + regId);
			// Registration is not present, register now with GCM
			GCMRegistrar.register(this, SENDER_ID);
		} else {
			// Device is already registered on GCM
			if (GCMRegistrar.isRegisteredOnServer(this)) {
				// Skips registration.
				
				 * Toast.makeText(getApplicationContext(),
				 * "Already registered with GCM", Toast.LENGTH_LONG) .show();
				 
				Log.e("abc", "=====111==" + regId);

			} else {
				// Try to register again, but not in the UI thread.
				// It's also necessary to cancel the thread onDestroy(),
				// hence the use of AsyncTask instead of a raw thread.
				final Context context = this;
				mRegisterTask = new AsyncTask<Void, Void, Void>() {

					@Override
					protected Void doInBackground(Void... params) {
						// Register on our server
						// On server creates a new user

						Log.e("abc", "===222====" + regId);
						ServerUtilities.register(context, regId);
						return null;
					}

					@Override
					protected void onPostExecute(Void result) {
					
					}
				};
				mRegisterTask.execute(null, null, null);
			}
		}*/

		// Quotes
		TabSpec tabQuotes = mTabHost.newTabSpec(
				getString(R.string.tab_quote).toString()).setIndicator(
				getTextView(0));
		mTabHost.addTab(tabQuotes, QuotesFragments.class, null);

		// Events
		TabSpec tabEvent = mTabHost.newTabSpec(
				getString(R.string.tab_events).toString()).setIndicator(
				getTextView(1));
		mTabHost.addTab(tabEvent, EventsFragment.class, null);

		// books
		TabSpec tabBooks = mTabHost.newTabSpec(
				getString(R.string.tab_book_review).toString()).setIndicator(
				getTextView(2));
		mTabHost.addTab(tabBooks, BookReviewFragment.class, null);

		// Videos
		TabSpec tabVideos = mTabHost.newTabSpec(
				getString(R.string.tab_videos_review).toString()).setIndicator(
				getTextView(3));
		mTabHost.addTab(tabVideos, VideoReviewFragment.class, null);

		mTabHost.getTabWidget().setBackgroundResource(TAB_HOST_BG[0]);

		mTabHost.setOnTabChangedListener(new OnTabChangeListener() {
			@Override
			public void onTabChanged(String tabId) {
				UsefullData.Log("Print tab:" + tabId);
				// int i = mTabHost.getCurrentTab();
				// UsefullData.Log("Print tab:fd " + i);
				// View v = mTabHost.getCurrentTabView();
				mTabHost.getTabWidget().setBackgroundResource(
						TAB_HOST_BG[mTabHost.getCurrentTab()]);
			}
		});

	}

	/**
	 * 
	 * Api to send GCM regID on news
	 * 
	 */
	/*// ======================================//
	private void callSubmitGCMIDApi(String regId) {

		Log.e("abc", "=====11111111======" + regId);
		RequestParams params = new RequestParams();

		params.put("regid", regId);

		HttpRestClient.post(REGISTER_GCM_URL, params,
				new AsyncHttpResponseHandler() {
					@Override
					public void onStart() {
						super.onStart();
						
						 * objUsefullData.showProgress(
						 * getString(R.string.msg_please_wait).toString(), "");
						 
					}

					@Override
					public void onSuccess(String response) {
						UsefullData.Log("" + response);
						try {
							JSONObject serverResp = new JSONObject(response);
							int success = serverResp.getInt("success");
							if (success == 1) {
								Log.e("abc",
										"+++++++++++++++ GCM Registed ++++++++++++");
							} else {
								Log.e("abc",
										"+++++++++++++++ GCM Not Registed ++++++++++++");
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					@Override
					public void onFinish() {
						// TODO Auto-generated method stub
						super.onFinish();
						 objUsefullData.dismissProgress(); 
					}
				});
	}

	*//**
	 * Receiving push messages
	 * *//*
	private final BroadcastReceiver mHandleMessageReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			String newMessage = intent.getExtras().getString("message");
			// Waking up mobile if it is sleeping
			WakeLocker.acquire(getApplicationContext());

			*//**
			 * Take appropriate action on this message depending upon your app
			 * requirement For now i am just displaying it on the screen
			 * *//*

			//Toast.makeText(getApplicationContext(),	"New Message: " + newMessage, Toast.LENGTH_LONG).show();

			// Releasing wake lock
			WakeLocker.release();
		}
	};
*/
	// ==============================================//
	private View getTextView(int i) {
		LayoutInflater inflate = getLayoutInflater();
		LinearLayout ll = (LinearLayout) inflate.inflate(
				R.layout.layout_tab_view, null);

		ImageView iconImg = (ImageView) ll.findViewById(R.id.tab_iconImg);
		TextView text = (TextView) ll.findViewById(R.id.tab_text);
		iconImg.setBackgroundResource(TAB_VIEW[i][1]);
		text.setText(TAB_VIEW[i][0]);
		return ll;
	}

	
}
