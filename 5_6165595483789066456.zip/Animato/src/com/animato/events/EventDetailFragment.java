package com.animato.events;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.animato.common.BaseFragment;
import com.animato.common.MyEvents;
import com.animato.common.UsefullData;
import com.wa.animato.R;

public class EventDetailFragment extends BaseFragment {

	private MyEvents events;
	private static final String KEY_STORE = "nitname_event_keys";
	private TextView tvDateTime, tvTitle, tvDesc, tvLoc, tvDate, tvTime,
			tvCost, tvUrl;

	// ====================================================//

	public static Fragment newInstances(MyEvents events) {
		Fragment fragment = new EventDetailFragment();
		Bundle b = new Bundle();
		b.putSerializable(KEY_STORE, events);
		fragment.setArguments(b);
		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		events = (MyEvents) getArguments().getSerializable(KEY_STORE);

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.event_detail_fragment, container,
				false);

		tvDateTime = (TextView) view.findViewById(R.id.tvDateTime);
		tvTitle = (TextView) view.findViewById(R.id.tvTitle);
		tvDesc = (TextView) view.findViewById(R.id.tvDesc);
		tvLoc = (TextView) view.findViewById(R.id.tvLoc);
		tvDate = (TextView) view.findViewById(R.id.tvDate);
		tvTime = (TextView) view.findViewById(R.id.tvTime);
		tvCost = (TextView) view.findViewById(R.id.tvCost);
		tvUrl = (TextView) view.findViewById(R.id.tvUrl);

		tvDateTime.setText(UsefullData.getFormattedDate(events.event_start_date));
		
		tvDate.setText(UsefullData.getFormattedDate(events.event_start_date));
		tvTitle.setText(events.event_title);
		
		String detail = events.event_details.replace("\u00a0", " ").replace("\r", "").replace("&nbsp;", "");
		tvDesc.setText(detail);
		

		tvLoc.setText(events.event_location);
		tvTime.setText(events.event_time);
		tvCost.setText(" " + events.event_cost);

		final ArrayList<String> al = pullLinks(events.event_details);
		if (al.size() > 0)
			tvUrl.setText(al.get(0).toString());
		return view;
	}

	// ====================================================//
	private ArrayList<String> pullLinks(String text) {

		ArrayList<String> links = new ArrayList<String>();

		String regex = "\\(?\\b(http://|www[.])[-A-Za-z0-9+&@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&@#/%=~_()|]";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(text);
		while (m.find()) {
			String urlStr = m.group();
			if (urlStr.startsWith("(") && urlStr.endsWith(")")) {
				urlStr = urlStr.substring(1, urlStr.length() - 1);
			}
			links.add(urlStr);
		}
		return links;
	}

}
