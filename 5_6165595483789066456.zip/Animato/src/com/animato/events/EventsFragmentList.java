package com.animato.events;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.animato.adapter.MyEventsAdapter;
import com.animato.common.BaseFragment;
import com.animato.common.HttpRestClient;
import com.animato.common.MyEvents;
import com.animato.common.UsefullData;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.wa.animato.R;

public class EventsFragmentList extends BaseFragment {
	/**
	 * Provide names to variables
	 */
	private ListView lvEvents;
	private MyEventsAdapter objAdapter;
	
	private ImageButton ibEFacebook;
	
	private String month; 
	
	private String loc; 
	
	private String type;
	private Button ibEShop;

	private TextView recordTV;
	/**
	 * on create view method for fragment
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater
				.inflate(R.layout.fragment_events_list, container, false);
		view.setOnClickListener(null);
		/**
		 * Initialization of variables
		 */
		objAdapter = new MyEventsAdapter(getActivity(), getFragmentManager());
		lvEvents = (ListView) view.findViewById(R.id.lvEvents);
		ibEFacebook = (ImageButton) view.findViewById(R.id.ibEFacebook);
		ibEShop = (Button)view.findViewById(R.id.ibEShop);
		recordTV = (TextView) view.findViewById(R.id.recordTV);
		lvEvents.setAdapter(objAdapter);
		
		
		
		Bundle b =  getArguments();
		
		month =  b.getString("month");
		loc =  b.getString("country");
		type =  b.getString("type");
		
		callSubmitCommentApi();

		/**
		 * 
		 * Social sites buttons with their clicks
		 * 
		 */

		// ================================================//
		ibEFacebook.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				WebView webview = new WebView(getActivity());
				webview.getSettings().setJavaScriptEnabled(true);

				webview.loadUrl("http://facebook.com/animatostrings");
			}
		});
		
		  
		ibEShop.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					WebView webview = new WebView(getActivity());
					webview.getSettings().setJavaScriptEnabled(true);

					webview.loadUrl("http://animato.com.au/store");
				}
			});
			

		return view;

	}

	// =======================================//

	/**
	 * 
	 * Api to comment on news
	 * 
	 */
	// ======================================//
	private void callSubmitCommentApi() {

		RequestParams params = new RequestParams();

		params.put("country", loc);
		params.put("month", month);
		params.put("event_type", type);

		HttpRestClient.post(EVENTS_URL, params, new AsyncHttpResponseHandler() {
			@Override
			public void onStart() {
				super.onStart();
				objUsefullData.showProgress(getString(R.string.msg_please_wait)
						.toString(), "");
			}

			@Override
			public void onSuccess(String response) {
				UsefullData.Log("" + response);
				try {
					JSONObject serverResp = new JSONObject(response);
					String success = serverResp.getString("success");
					objAdapter.clearItem();
					if (success.equals("1")) {
					//	objAdapter.clearItem();
						JSONArray countryResult = serverResp
								.getJSONArray("data");

						for (int i = 0; i < countryResult.length(); i++) {

							JSONObject eventsJson = countryResult
									.getJSONObject(i);

							String event_id = eventsJson.getString("id");

							String event_start_date = eventsJson
									.getString("start_date");

							String event_end_date = eventsJson
									.getString("end_date");

							String event_time = eventsJson.getString("time");

							String event_title = eventsJson.getString("title");

							String event_location = eventsJson
									.getString("location");

							String event_cost = eventsJson.getString("cost");

							String event_details = eventsJson
									.getString("details");

							MyEvents myEvents = new MyEvents();
							myEvents.event_id = event_id;
							myEvents.event_start_date = event_start_date;
							myEvents.event_end_date = event_end_date;
							myEvents.event_time = event_time;
							myEvents.event_title = event_title;
							myEvents.event_location = event_location;
							myEvents.event_cost = event_cost;
							myEvents.event_details = event_details;

							objAdapter.addItem(myEvents);

						}
					} else {
						objUsefullData.showMsgOnUI("No Event available.");
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void onFinish() {
				// TODO Auto-generated method stub
				super.onFinish();
				objUsefullData.dismissProgress();
				
				if (objAdapter.getCount() > 0) {
					objAdapter.sortList();
					objAdapter.notifyDataSetChanged();
					recordTV.setVisibility(View.INVISIBLE);
					lvEvents.setVisibility(View.VISIBLE);
					
				} else {
					lvEvents.setVisibility(View.INVISIBLE);
					recordTV.setVisibility(View.VISIBLE);
				}
			}
		});
	}


}
