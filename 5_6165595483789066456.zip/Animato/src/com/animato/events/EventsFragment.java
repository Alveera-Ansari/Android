package com.animato.events;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import com.animato.common.BaseFragment;
import com.animato.common.EditTextWithDeleteButton;
import com.animato.common.HttpRestClient;
import com.animato.common.UsefullData;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.wa.animato.R;

public class EventsFragment extends BaseFragment {

	/**
	 * Provide names to variables
	 */

	private ImageButton ibEFacebook;

	private EditTextWithDeleteButton countryED;
	private EditTextWithDeleteButton eventTypeED;
	private EditTextWithDeleteButton monthED;

	private Button countryBtn;
	private Button eventTypeBtn;
	private Button monthBtn;
	private Button searchBtn;

	private int select = -1;

	private Button btnSubmit;

	private Button ibEDShop;

	private ArrayList<String> countrylist = new ArrayList<String>();
	private ArrayList<String> eventlist = new ArrayList<String>();

	/**
	 * on create view method for fragment
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater
				.inflate(R.layout.fragment_events, container, false);
		view.setOnClickListener(null);

		/**
		 * Initialization of variables
		 */

		ibEFacebook = (ImageButton) view.findViewById(R.id.ibEFacebook);

		countryED = (EditTextWithDeleteButton) view
				.findViewById(R.id.countryED);
		eventTypeED = (EditTextWithDeleteButton) view
				.findViewById(R.id.eventTypeED);
		monthED = (EditTextWithDeleteButton) view.findViewById(R.id.monthED);

		countryBtn = (Button) view.findViewById(R.id.countryBtn);
		eventTypeBtn = (Button) view.findViewById(R.id.eventTypeBtn);
		monthBtn = (Button) view.findViewById(R.id.monthBtn);
		searchBtn = (Button) view.findViewById(R.id.searchBtn);
		ibEDShop = (Button) view.findViewById(R.id.ibEDShop);

		btnSubmit = (Button) view.findViewById(R.id.btnSubmit);

		/**
		 * 
		 * Social sites buttons with their clicks
		 * 
		 */

		// ================================================//
		ibEFacebook.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				openWebView("http://facebook.com/animatostrings");
			}
		});

		ibEDShop.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				openWebView("http://animato.com.au/store");
			}
		});

		// =======================================//
		countryBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				if (countrylist.size() > 0) {
					openCountryAlert();
				} else {
					callCountryApi();
				}
			}
		});

		// =======================================//
		eventTypeBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				if (eventlist.size() > 0) {
					openEventAlert();
				} else {
					callEventApi();

				}

			}
		});

		// =======================================//
		monthBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				openMonthAlert();
			}
		});

		searchBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				String month = "";

				if (monthED.getText().toString().equalsIgnoreCase("January")) {
					month = "01";
				} else if (monthED.getText().toString()
						.equalsIgnoreCase("February")) {
					month = "02";
				} else if (monthED.getText().toString()
						.equalsIgnoreCase("March")) {
					month = "03";
				} else if (monthED.getText().toString()
						.equalsIgnoreCase("April")) {
					month = "04";
				} else if (monthED.getText().toString().equalsIgnoreCase("May")) {
					month = "05";
				}

				else if (monthED.getText().toString().equalsIgnoreCase("June")) {
					month = "06";
				} else if (monthED.getText().toString()
						.equalsIgnoreCase("July")) {
					month = "07";
				} else if (monthED.getText().toString().equalsIgnoreCase("August")) {
					month = "08";
				} else if (monthED.getText().toString()
						.equalsIgnoreCase("September")) {
					month = "09";
				} else if (monthED.getText().toString()
						.equalsIgnoreCase("October")) {
					month = "10";
				} else if (monthED.getText().toString()
						.equalsIgnoreCase("November")) {
					month = "11";
				} else if (monthED.getText().toString()
						.equalsIgnoreCase("December")) {
					month = "12";
				}

				if (countryED.getText().toString().length() == 0
						&& monthED.getText().toString().length() == 0
						&& eventTypeED.getText().toString().length() == 0) {

					objUsefullData.showMsgOnUI("Fill any of the field.");

				} else {

					Fragment f = new EventsFragmentList();

					FragmentTransaction ft = getFragmentManager()
							.beginTransaction();

					Bundle b = new Bundle();

					b.putString("month", month + "");
					b.putString("country", countryED.getText().toString());
					b.putString("type", eventTypeED.getText().toString());

					f.setArguments(b);

					ft.replace(R.id.rlEventMain, f);

					ft.addToBackStack(null);
					ft.commit();
				}

			}
		});

		countryED.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				countryED.setText("");
			}
		});

		eventTypeED.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				eventTypeED.setText("");
			}
		});

		
		monthED.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				monthED.setText("");
			}
		});

		btnSubmit.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Fragment fragment = new EventAddNewEventFragment();
				FragmentTransaction ft = getFragmentManager()
						.beginTransaction();
				ft.replace(R.id.rlEventMain, fragment);
				ft.addToBackStack(null);
				ft.commit();

			}
		});
		return view;

	}

	/*
	 * private void openWebView(String loadUrl){ WebView webview = new
	 * WebView(getActivity()); webview.getSettings().setJavaScriptEnabled(true);
	 * 
	 * webview.loadUrl(loadUrl); }
	 */

	// ======================================//
	private void callCountryApi() {

		HttpRestClient.get(COUNTRY_URL, new AsyncHttpResponseHandler() {

			@Override
			public void onStart() {
				super.onStart();
				 objUsefullData.showProgress("Please wait..", "");
			}

			@Override
			public void onSuccess(String response) {
				UsefullData.Log("" + response);
				try {
					JSONObject serverResp = new JSONObject(response);
					String success = serverResp.getString("success");
					if (success.equals("1")) {
						JSONArray countryResult = serverResp
								.getJSONArray("data");

						for (int i = 0; i < countryResult.length(); i++) {

							JSONObject obj = countryResult.getJSONObject(i);

							countrylist.add(obj.getString("country_name")
									.replace("\n", ""));
						}

						Collections.sort(countrylist, new Comparator<String>() {
							@Override
							public int compare(String s1, String s2) {
								return s1.compareToIgnoreCase(s2);
							}
						});
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			@Override
			public void onFinish() {
				super.onFinish();
				 objUsefullData.dismissProgress();

				if (countrylist.size() > 0) {
					openCountryAlert();
				} else {
					objUsefullData.showMsgOnUI("Locality data is not found");
				}
				
			}
		});

	}

	// ======================================//
	private void callEventApi() {

		HttpRestClient.get(EVENT_TYPE_URL, new AsyncHttpResponseHandler() {

			@Override
			public void onStart() {
				super.onStart();
				objUsefullData.showProgress("Please wait..", "");
			}

			@Override
			public void onSuccess(String response) {
				UsefullData.Log("" + response);
				try {
					JSONObject serverResp = new JSONObject(response);
					String success = serverResp.getString("success");
					if (success.equals("1")) {
						JSONArray countryResult = serverResp
								.getJSONArray("data");

						for (int i = 0; i < countryResult.length(); i++) {

							JSONObject obj = countryResult.getJSONObject(i);

							eventlist.add(obj.getString("event_type_name")
									.replace("\n", ""));
						}

						Collections.sort(eventlist, new Comparator<String>() {
							@Override
							public int compare(String s1, String s2) {
								return s1.compareToIgnoreCase(s2);
							}
						});
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			@Override
			public void onFinish() {
				super.onFinish();
				objUsefullData.dismissProgress();

				if (eventlist.size() > 0) {
					openEventAlert();
				} else {
					objUsefullData.showMsgOnUI("Events" +
							" data is not found");
				}

			}
		});

	}

	// =========================================//
	private void openCountryAlert() {

		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

		builder.setTitle(getString(R.string.select_country).toString());
		builder.setSingleChoiceItems(
				countrylist.toArray(new String[countrylist.size()]), -1,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						countryED.setText(countrylist.get(which));
						dialog.dismiss();
					}
				});

		builder.setNegativeButton(getString(R.string.btn_cancel).toString(),
				null);
		builder.show();
	}

	// =========================================//

	private void openEventAlert() {

		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

		builder.setTitle(getString(R.string.select_facilitator).toString());
		builder.setSingleChoiceItems(
				eventlist.toArray(new String[eventlist.size()]), -1,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						eventTypeED.setText(eventlist.get(which));
						dialog.dismiss();
					}
				});

		builder.setNegativeButton(getString(R.string.btn_cancel).toString(),
				null);
		builder.show();
	}

	// =========================================//
	private void openMonthAlert() {

		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

		builder.setTitle(getString(R.string.select_months).toString());
		builder.setSingleChoiceItems(MONTHS, -1,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						select = which + 1;
						monthED.setText(MONTHS[which]);
						dialog.dismiss();

					}
				});

		builder.setNegativeButton(getString(R.string.btn_cancel).toString(),
				null);
		builder.show();
	}

}
