package com.animato.events;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.animato.common.BaseFragment;
import com.animato.common.EditTextWithDeleteButton;
import com.animato.common.HttpRestClient;
import com.animato.common.UsefullData;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.wa.animato.R;

public class EventAddNewEventFragment extends BaseFragment {

	/**
	 * Provide names to variables
	 */

	private EditTextWithDeleteButton localityED;
	private EditTextWithDeleteButton eventTypeED;

	private ImageButton ibEAFacebook;

	private EditText etTitle;
	private EditText etDesc;
	// private EditText etLocality;
	// private EditText etEventType;
	private EditText etDate;
	private EditText etCost;

	private Button localityBtn;
	private Button eventBtn;
	private Button searchBtn;

	private EditText etVenue;
	private EditText etName;
	private EditText etEmail;
	private EditText etContactPhone;

	private LinearLayout llSuccess;

	private int select = -1;
	private String currentDate;

	private Button ibEAShop;

	private EditText etTime;

	private String finalDate;

	private ArrayList<String> countrylist = new ArrayList<String>();
	private ArrayList<String> eventlist = new ArrayList<String>();
	private LinearLayout sv;

	/**
	 * on create view method for fragment
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		final View view = inflater.inflate(R.layout.fragment_events_submit,
				container, false);
		view.setOnClickListener(null);

		/**
		 * Initialization of variables
		 */
		sv = (LinearLayout) view.findViewById(R.id.sv);
		ibEAFacebook = (ImageButton) view.findViewById(R.id.ibEAFacebook);
		etVenue = (EditText) view.findViewById(R.id.etVenue);
		etName = (EditText) view.findViewById(R.id.etName);
		etEmail = (EditText) view.findViewById(R.id.etEmail);
		etContactPhone = (EditText) view.findViewById(R.id.etContactPhone);
		etTitle = (EditText) view.findViewById(R.id.etTitle);
		etDesc = (EditText) view.findViewById(R.id.etDesc);
		etDate = (EditText) view.findViewById(R.id.etDate);
		etTime = (EditText) view.findViewById(R.id.etTime);
		etDate.setFocusable(false);
		etTime.setFocusable(false);

		localityBtn = (Button) view.findViewById(R.id.localityBtn);
		eventBtn = (Button) view.findViewById(R.id.eventBtn);
		etCost = (EditText) view.findViewById(R.id.etCost);

		searchBtn = (Button) view.findViewById(R.id.searchBtn);

		llSuccess = (LinearLayout) view.findViewById(R.id.llSuccess);
		ibEAShop = (Button) view.findViewById(R.id.ibEAShop);

		eventTypeED = (EditTextWithDeleteButton) view
				.findViewById(R.id.eventTypeED);
		localityED = (EditTextWithDeleteButton) view
				.findViewById(R.id.etLocality);
		/**
		 * 
		 * Social sites buttons with their clicks
		 * 
		 */

		// ================================================//
		ibEAFacebook.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				openWebView("http://facebook.com/animatostrings");
			}
		});

		ibEAShop.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				openWebView("http://animato.com.au/store");
			}
		});

		// =============================================//
		etDate.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				openDateDialog(etDate);

			}
		});

		// =============================================//
		etTime.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				openTimeDialog(etTime);
			}
		});

		// =============================================//
		localityBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (countrylist.size() > 0) {
					openLocalityAlert();
				} else {
					callLocalityApi();
				}
			}
		});

		// =======================================//
		searchBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (checkValidation()) {
					try {
						callSubmitCommentApi();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});

		// =======================================//
		eventBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (eventlist.size() > 0) {
					openEventAlert();
				} else {
					callEventApi();

				}
			}
		});

		/*
		 * // ====================================//
		 * etTitle.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etLocality.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etDesc.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etEventType.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etMonth.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etVenue.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etEmail.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etName.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etContactPhone.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 * 
		 * etTime.setOnFocusChangeListener(new OnFocusChangeListener() {
		 * 
		 * @Override public void onFocusChange(View v, boolean hasFocus) { //
		 * TODO Auto-generated method stub llSuccess.setVisibility(View.GONE); }
		 * });
		 */

		view.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyboard();
			}
		});

		sv.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyboard();
			}
		});

		/*
		 * ivLocality.setOnClickListener(new OnClickListener() {
		 * 
		 * @Override public void onClick(View v) { // TODO Auto-generated method
		 * stub etLocality.setText("");
		 * ivLocality.setVisibility(View.INVISIBLE); } });
		 * 
		 * ivEventType.setOnClickListener(new OnClickListener() {
		 * 
		 * @Override public void onClick(View v) { // TODO Auto-generated method
		 * stub etEventType.setText("");
		 * ivEventType.setVisibility(View.INVISIBLE); } });
		 */

		return view;
	}

	// ======================================//

	private void hideKeyboard() {
		InputMethodManager inputManager = (InputMethodManager) getActivity()
				.getSystemService(Context.INPUT_METHOD_SERVICE);

		// check if no view has focus:
		View view = getActivity().getCurrentFocus();
		if (view != null) {
			inputManager.hideSoftInputFromWindow(view.getWindowToken(),
					InputMethodManager.HIDE_NOT_ALWAYS);
		}
	}

	// ======================================//
	private boolean checkValidation() {
		if (objValidation.checkEmpty(etTitle, "Title")) {
			return false;
		}
		if (objValidation.checkEmpty(etDesc, "Description")) {
			return false;
		}
		if (objValidation.checkEmpty(localityED.getEditText(), "Location")) {
			return false;
		}
		if (objValidation.checkEmpty(eventTypeED.getEditText(), "Event Type")) {
			return false;
		}
		if (objValidation.checkEmpty(etDate, "Date")) {
			return false;
		}
		if (objValidation.checkEmpty(etTime, "Time")) {
			return false;
		}
		if (objValidation.checkEmpty(etCost, "Cost")) {
			return false;
		}
		if (objValidation.checkEmpty(etVenue, "Venue")) {
			return false;
		}
		if (objValidation.checkEmpty(etEmail, "Email")) {
			return false;
		}
		if (!objValidation.checkForEmail(etEmail, "Email")) {
			return false;
		}
		if (objValidation.checkEmpty(etName, "Name")) {
			return false;
		}
		if (objValidation.checkEmpty(etContactPhone, "Contact Phone")) {
			return false;
		}
		return true;
	}

	// =========================================//
	private void openLocalityAlert() {

		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

		builder.setTitle(getString(R.string.select_country).toString());
		builder.setSingleChoiceItems(
				countrylist.toArray(new String[countrylist.size()]), -1,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						localityED.setText(countrylist.get(which));

						dialog.dismiss();
					}
				});

		builder.setNegativeButton(getString(R.string.btn_cancel).toString(),
				null);
		builder.show();
	}

	// =========================================//

	private void openEventAlert() {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

		builder.setTitle(getString(R.string.select_facilitator).toString());
		builder.setSingleChoiceItems(
				eventlist.toArray(new String[eventlist.size()]), -1,
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						eventTypeED.setText(eventlist.get(which));

						dialog.dismiss();
					}
				});

		builder.setNegativeButton(getString(R.string.btn_cancel).toString(),
				null);
		builder.show();
	}

	// ======================================//
	private void callLocalityApi() {
		HttpRestClient.get(COUNTRY_URL, new AsyncHttpResponseHandler() {
			@Override
			public void onStart() { // TODO Auto-generated method stub
				super.onStart();
				objUsefullData.showProgress("Please wait..", "");
			}

			@Override
			public void onSuccess(String response) {
				UsefullData.Log("" + response);
				try {
					JSONObject serverResp = new JSONObject(response);
					String success = serverResp.getString("success");
					if (success.equals("1")) {
						JSONArray countryResult = serverResp
								.getJSONArray("data");
						for (int i = 0; i < countryResult.length(); i++) {
							JSONObject obj = countryResult.getJSONObject(i);
							countrylist.add(obj.getString("country_name"));
						}

						Collections.sort(countrylist, new Comparator<String>() {
							@Override
							public int compare(String s1, String s2) {
								return s1.compareToIgnoreCase(s2);
							}
						});
					}
				} catch (JSONException e) { // TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void onFinish() { // TODO Auto-generated method stub
				super.onFinish();
				objUsefullData.dismissProgress();
				// callEventApi();
				if (countrylist.size() > 0) {
					openLocalityAlert();
				} else {
					objUsefullData.showMsgOnUI("Locality data is not found");
				}
			}
		});

	}

	// ======================================//
	private void callEventApi() {

		HttpRestClient.get(EVENT_TYPE_URL, new AsyncHttpResponseHandler() {

			@Override
			public void onStart() {
				super.onStart();
				objUsefullData.showProgress("Please wait..", "");
			}

			@Override
			public void onSuccess(String response) {
				UsefullData.Log("" + response);
				try {
					JSONObject serverResp = new JSONObject(response);
					String success = serverResp.getString("success");
					if (success.equals("1")) {
						JSONArray countryResult = serverResp
								.getJSONArray("data");

						for (int i = 0; i < countryResult.length(); i++) {

							JSONObject obj = countryResult.getJSONObject(i);

							eventlist.add(obj.getString("event_type_name")
									.replace("\n", ""));
						}

						Collections.sort(eventlist, new Comparator<String>() {
							@Override
							public int compare(String s1, String s2) {
								return s1.compareToIgnoreCase(s2);
							}
						});
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			@Override
			public void onFinish() {
				super.onFinish();
				objUsefullData.dismissProgress();
				if (eventlist.size() > 0) {
					openEventAlert();
				} else {
					objUsefullData.showMsgOnUI("Locality data is not found");
				}
			}
		});

	}

	/**
	 * 
	 * Api to comment on news
	 * @throws ParseException 
	 * 
	 */
	// ======================================//
	private void callSubmitCommentApi() throws ParseException {

		RequestParams params = new RequestParams();

		/*
		 * String myDate = etMonth.getText().toString();
		 * 
		 * String firstWord = null; String secondWord = null; String thirdWord =
		 * null; try { String arr[] = myDate.split("-", 3); firstWord = arr[0];
		 * 
		 * Log.e("abc", "=========" + firstWord); secondWord = arr[1];
		 * 
		 * Log.e("abc", "=========" + secondWord); thirdWord = arr[2];
		 * 
		 * Log.e("abc", "=========" + thirdWord); } catch (Exception e) { //
		 * TODO: handle exception Log.e("abc", "===========" + e); }
		 * 
		 * try { if ((firstWord.length() < 1) || secondWord.length() < 1 ||
		 * thirdWord.length() != 4) {
		 * 
		 * // if (isValidFormat(etMonth.getText().toString())) {
		 * 
		 * objUsefullData.showMsgOnUI("Insert Date in DD-MM-YYYY format.");
		 * 
		 * } else {
		 * 
		 * String month = StringUtils.substringBetween(etMonth.getText()
		 * .toString(), "-");
		 * 
		 * if (Integer.parseInt(month) > 12 || Integer.parseInt(month) < 1) {
		 * objUsefullData.showMsgOnUI("Fill correct date."); } else {
		 * Log.e("abc", "+++++++++" + etMonth.getText().toString());
		 * 
		 * 
		 * http://animato.newsupdate.net.au/api/event-entry.php? start_date
		 * =2014-10-22&time=9:30&title=jai ho
		 * &location=chandigarh&cost=123&event_type=New Online RFP
		 * Tool&details=testing testing testing &venue=this is venue&user_name
		 * =sandy&user_phone=9211420&user_email=as@gmail.com
		 * 
		 * 
		 * SimpleDateFormat getCurrentFormat = new SimpleDateFormat(
		 * "dd-MM-yyyy");
		 * 
		 * Date currentDate = null; try { currentDate =
		 * getCurrentFormat.parse(etMonth.getText() .toString()); Log.e("",
		 * "##################33" + currentDate); } catch (ParseException e) {
		 * // TODO Auto-generated catch block Log.e("abc", "=======11=======" +
		 * e); }
		 * 
		 * SimpleDateFormat format1 = new SimpleDateFormat( "yyyy-MM-dd");
		 * Log.e("", "##################@@@" + format1.format(currentDate));
		 * 
		 * String arr1[] = format1.format(currentDate).split("-", 3); String
		 * firstWord1 = arr1[0]; String secondWord1 = arr1[1]; String thirdWord1
		 * = arr1[2];
		 * 
		 * if (thirdWord1.startsWith("0") || secondWord1.startsWith("0")) {
		 * thirdWord1 = thirdWord1.replaceFirst( thirdWord1.charAt(0) + "", "");
		 * secondWord1 = secondWord1.replaceFirst( secondWord1.charAt(0) + "",
		 * "");
		 * 
		 * Log.e("", "#########" + firstWord1 + "-" + secondWord1 + "-" +
		 * thirdWord1); params.put("start_date", firstWord1 + "-" + secondWord1
		 * + "-" + thirdWord1); } else { Log.e("", "++++++" + firstWord1 + "-" +
		 * secondWord1 + "-" + thirdWord1); params.put("start_date",
		 * format1.format(currentDate)); }
		 * 
		 * }
		 */

		Date firstDate = null;

		SimpleDateFormat input = new SimpleDateFormat("dd:MM:yyyy");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd");

		firstDate = input.parse(etDate.getText().toString()); // parse input
		finalDate = output.format(firstDate);

		params.put("start_date", finalDate);
		params.put("time", etTime.getText().toString());
		params.put("title", etTitle.getText().toString());
		params.put("location", localityED.getText().toString());
		params.put("cost", etCost.getText().toString());
		params.put("event_type", eventTypeED.getText().toString());
		params.put("details", etDesc.getText().toString());
		params.put("venue", etVenue.getText().toString());
		params.put("user_name", etName.getText().toString());
		params.put("user_phone", etContactPhone.getText().toString());
		params.put("user_email", etEmail.getText().toString().trim());

		HttpRestClient.post(EVENT_ENTERY, params,
				new AsyncHttpResponseHandler() {
					@Override
					public void onStart() {
						super.onStart();
						objUsefullData.showProgress(
								getString(R.string.msg_please_wait).toString(),
								"");
					}

					@Override
					public void onSuccess(String response) {
						UsefullData.Log("" + response);
						try {
							JSONObject serverResp = new JSONObject(response);
							String success = serverResp.getString("success");
							if (success.equals("1")) {
								llSuccess.setVisibility(View.VISIBLE);

								cleanData();
								objUsefullData
										.showMsgOnUI("Event Added Successfully.");

							} else {
								objUsefullData.showMsgOnUI("Event Not Added.");
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					@Override
					public void onFinish() {
						// TODO Auto-generated method stub
						super.onFinish();
						objUsefullData.dismissProgress();
					}

				});

	}

	// ==================================//

	private void cleanData() {
		etDate.setText("");
		etTitle.setText("");
		eventTypeED.setText("");
		etCost.setText("");
		eventTypeED.setText("");
		localityED.setText("");
		etDesc.setText("");
		etVenue.setText("");
		etEmail.setText("");
		etContactPhone.setText("");
		etName.setText("");
		etTime.setText("");
	}

	// ==================================//

	public boolean isValidFormat(String value) {

		SimpleDateFormat getCurrentFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date = null;
		try {
			date = getCurrentFormat.parse(value);

			Log.e("abc", "==============" + date.toString());
		} catch (ParseException ex) {
			Log.e("abc", "=======Date format exception=======" + ex);
		}
		return date != null;
	}
}
