package com.animato.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.net.ParseException;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.webkit.WebView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import com.animato.lazyloading.ImageLoader;

public class BaseFragment extends Fragment implements ConstantValue {

	public SaveData objSaveData;
	public Validation objValidation;

	public UsefullData objUsefullData;
	
	public ImageLoader objImageLoader;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		objSaveData = new SaveData(getActivity());
		objValidation = new Validation(getActivity());
		objUsefullData = new UsefullData(getActivity());
		objImageLoader = new ImageLoader(getActivity());
	}

	// ==================================//
	public void showDummyMessage() {
		objUsefullData.showMsgOnUI("under development");
	}

	// ==================================//
	public void openWebView(String urlLoad) {
		WebView webview = new WebView(getActivity());
		webview.getSettings().setJavaScriptEnabled(true);
		webview.loadUrl(urlLoad);
	}

	// ======================================//
	public void openTimeDialog(final EditText editText) {

		Calendar c = Calendar.getInstance();

		TimePickerDialog picker = new TimePickerDialog(getActivity(),
				new TimePickerDialog.OnTimeSetListener() {
					@Override
					public void onTimeSet(TimePicker view, int h, int m) {
						String str = getTag(h) + ":" + getTag(m);
						editText.setText("" + str);
					}
				}, c.get(Calendar.HOUR), c.get(Calendar.MINUTE), false);

		picker.show();

	}

	// ======================================//
	public void openDateDialog(final EditText editText) {

		Calendar c = Calendar.getInstance();
		DatePickerDialog dialog = new DatePickerDialog(getActivity(),
				new OnDateSetListener() {

					@Override
					public void onDateSet(DatePicker view, int year,
							int monthOfYear, int dayOfMonth) {
						String str = getTag(dayOfMonth) + ":" + getTag(monthOfYear + 1) + ":"
								+ year;
						Log.e("date selected:", str);
						
					 
						try {
							
						    editText.setText("" + str);

						} catch (ParseException e) {
						    e.printStackTrace();
						} 
						
						
					}
				}, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
				c.get(Calendar.DAY_OF_MONTH));

		dialog.show();

	}

	// ======================================//
	private String getTag(int t) {
		if (t < 10)
			return "0" + t;
		else
			return "" + t;

	}
}
