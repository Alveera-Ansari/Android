package com.animato.common;

public class ItemInfo {

	public String itemCode = "";
	public String itemImage = "";
	public String itemName = "";
	
	
//public String value_gtin_code = null;
public String value_gtin_name = null;
public String value_gtin_product_line = null;
public String value_gtin_weight = null;
public String value_gtin_volume = null;
public String value_gtin_alcool = null;
public String value_gtin_img = null;
public String value_gtin_img_default = null;

public String value_brand_code = null;
public String value_brand_name = null;
public String value_brand_type = null;
public String value_brand_link = null;
public String value_brand_img = null;
public String value_brand_img_default = null;

public String value_group_code = null;
public String value_group_name = null;

public String value_gcp_code = null;

public String value_gpc_img = null;
public String value_gpc_img_default = null;
public String value_gpc_segment_code = null;
public String value_gpc_segment_name = null;
public String value_gpc_family_code = null;
public String value_gpc_family_name = null;	
public String value_gpc_class_code = null;
public String value_gpc_class_name = null;
public String value_gpc_brick_code = null;
public String value_gpc_brick_name = null;

public String value_gepir_source = null;
public String value_gepir_return_code_code = null;
public String value_gepir_return_code_name = null;	
public String value_gepir_gln_code = null;
public String value_gepir_gln_name = null;
public String value_gepir_gln_address_1 = null;
public String value_gepir_gln_address_2 = null;
public String value_gepir_gln_address_3 = null;
public String value_gepir_gln_cp = null;
public String value_gepir_gln_city = null;
public String value_gepir_gln_country = null;
	
}
