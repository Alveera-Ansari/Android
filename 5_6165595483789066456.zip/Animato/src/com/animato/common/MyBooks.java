package com.animato.common;

import java.io.Serializable;

public class MyBooks implements Serializable {

	/*
	 * [{"book_name":"Living Reality ",
	 * "auth_name":"Sailor Bob Adamson",
	 * "book_icon":"http:\/\/nondualitycommunity.org\/iphone\/icons\/Living_Reality.jpg",
	 * "url":"http:\/\/www.amazon.com\/gp\/product\/0935895108\/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=",
	 * "review":["This is a diary of James Braha who had invited Sailor Bob Adamson to come to the USA for ."]}]
	 * */

	private static final long serialVersionUID = 1L;
	//private String video_id = "";
	private String book_name = "";
	private String auth_name = "";
	private String book_icon = "";
	
	private String url = "";
	//private String youtube_url = "";
	private String review = "";
	

	public MyBooks(String book_name, String auth_name, String book_icon, String url, String review) {

		//this.video_id = video_id;
		this.book_name = book_name;
		this.auth_name = auth_name;
		this.book_icon = book_icon;
		this.url = url;
		//this.youtube_url = youtube_url;
		this.review = review;
		
	}

	/*public String getVedioId() {
		return video_id;
	}*/

	public String getBookName() {
		return book_name;
	}

	public String getAuthName() {
		return auth_name;
	}

	public String getBookUrl() {
		return url;
	}

	public String getBookIconUrl() {
		return book_icon;
	}
	public String getReviews() {
		return review;
	}

	

	

}
