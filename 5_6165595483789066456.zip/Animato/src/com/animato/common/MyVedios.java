package com.animato.common;

import java.io.Serializable;

public class MyVedios implements Serializable {

	/*
	 * [{"video_id":"16",
	 * "video_title":"Nonduality - To The Point","
	 * video_thumb":"http:\/\/nondualitycommunity.org\/iphone\/videos\/SailorBob.JPG",
	 * "videos":"http:\/\/nondualitycommunity.org\/iphone\/videos\/",
	 * "youtube_url":"https:\/\/www.youtube.com\/watch?v=fXOvMQO3sTE",
	 * "review":["Sailor
	 * Bob Adamson speaks about the essence of nonduality. He has a no-frills
	 * approach, meaning he is not beating around the bush."]}]
	 */

	private static final long serialVersionUID = 1L;
	private String video_id = "";
	private String video_title = "";
	private String video_thumb = "";
	private String videos = "";
	private String youtube_url = "";
	private String review = "";
	

	public MyVedios(String video_title, String video_thumb,
			String youtube_url, String review) {

		this.video_title = video_title;
		this.video_thumb = video_thumb;
		this.youtube_url = youtube_url;
		this.review = review;
		
	}

	public String getVedioId() {
		return video_id;
	}

	public String getVedioName() {
		return video_title;
	}

	public String getVideoThumb() {
		return video_thumb;
	}

	public String getVedioUrl() {
		return videos;
	}

	public String getYoutubeUrl() {
		return youtube_url;
	}

	public String getReviews() {
		return review;
	}

	

}
