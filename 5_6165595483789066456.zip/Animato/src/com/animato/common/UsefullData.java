package com.animato.common;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import com.wa.animato.R;

public class UsefullData implements ConstantValue {

	private Context _context;
	private ProgressDialog pDialog;

	public UsefullData(Context c) {
		_context = c;
	}

	// ================== DEVICE INFORMATION ============//

	public static String getCountryCodeFromDevice() {
		String countryCode = Locale.getDefault().getCountry();
		if (countryCode.equals("")) {
			countryCode = "IN";
		}
		return countryCode;
	}

	public static String getFormattedDate(String date) {
		Log("date: " + date);
		/*
		 * SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); Date
		 * currentDate = null; try { currentDate = format.parse(date); Log.v("",
		 * "##################33" + currentDate); } catch (ParseException e) {
		 * // TODO Auto-generated catch block e.printStackTrace(); } return
		 * currentDate+"";
		 */
		try {

			DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat targetFormat = new SimpleDateFormat("dd-MMM-yyyy");
			Date date1 = originalFormat.parse(date);
			date = targetFormat.format(date1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date + "";
	}

	// ================== CREATE FILE AND RELATED ACTION ============//

	public File getRootFile() {

		File f = new File(Environment.getExternalStorageDirectory(), _context
				.getString(R.string.app_name).toString());
		if (!f.isDirectory()) {
			f.mkdirs();
		}

		return f;
	}

	public void deleteRootDir(File root) {

		if (root.isDirectory()) {
			String[] children = root.list();
			for (int i = 0; i < children.length; i++) {
				File f = new File(root, children[i]);
				Log("file name:" + f.getName());
				if (f.isDirectory()) {
					deleteRootDir(f);
				} else {
					f.delete();
				}
			}
		}
	}

	// ================ DOWNLOAD ============================//

	public void downloadAndDisplayImage(final String image_url,
			final ImageView v, int type) {

		new Thread() {

			public void run() {
				try {

					InputStream in = new URL(image_url).openConnection()
							.getInputStream();
					Bitmap bm = BitmapFactory.decodeStream(in);
					File fileUri = new File(getRootFile(),
							getNameFromURL(image_url));
					FileOutputStream outStream = null;
					outStream = new FileOutputStream(fileUri);
					bm.compress(Bitmap.CompressFormat.JPEG, 75, outStream);
					outStream.flush();
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {

					File f = new File(getRootFile(), "aa.jpg");
					if (f.exists()) {
						final Bitmap bmp = BitmapFactory
								.decodeFile(f.getPath());

						v.post(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								v.setImageBitmap(bmp);
							}
						});

						Log("download images and showing ,,,,");

					}
				}
			}

		}.start();
	}

	public String getNameFromURL(String url) {

		String fileName = "item_image.jpg";
		if (url != null) {
			fileName = url.substring(url.lastIndexOf('/') + 1, url.length());
		}
		return fileName;
	}

	// ================== LOG AND TOAST====================//

	public static void Log(final String msg) {
		android.util.Log.e("animato", msg);
	}

	public void showMsgOnUI(final String msg) {
		((Activity) _context).runOnUiThread(new Runnable() {

			@Override
			public void run() {
				Toast.makeText(_context, msg, Toast.LENGTH_LONG).show();
			}
		});

	}

	// =================== INTERNET ===================//
	public boolean isNetworkConnected() {
		ConnectivityManager cm = (ConnectivityManager) _context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo ni = cm.getActiveNetworkInfo();
		if (ni == null) {
			return false;
		} else
			return true;
	}

	// ==================== PROGRESS DIALOG ==================//

	public void showProgress(final String msg, final String title) {

		try {
			pDialog = ProgressDialog.show(_context, title, msg, true);
		} catch (Exception e) {
			android.util.Log.e("UsefullData", "===========" + e);
		}
	}

	public void dismissProgress() {
		if (pDialog != null) {
			if (pDialog.isShowing()) {
				pDialog.cancel();
				pDialog = null;
			}
		}
	}

	// ====================SET FONT SIZE==================//
	public Typeface getUsedFontLucida() {
		Typeface typeFace = Typeface.createFromAsset(_context.getAssets(),
				"fonts/lucida_hand_writting.ttf");
		return typeFace;
	}

	public Typeface getUsedFontArial() {
		Typeface typeFace = Typeface.createFromAsset(_context.getAssets(),
				"fonts/arial.ttf");
		return typeFace;
	}

}
