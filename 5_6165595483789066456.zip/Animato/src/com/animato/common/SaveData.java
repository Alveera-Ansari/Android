package com.animato.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class SaveData implements ConstantValue {

	private Context _context;
	private SharedPreferences shared;
	private String SHARED_NAME = "_sos_pizza";
	private Editor edit;

	public SaveData(Context c) {
		_context = c;
		shared = _context.getSharedPreferences(SHARED_NAME,
				Context.MODE_PRIVATE);
		edit = shared.edit();
	}

	// ============================================//
	public void save(String key, String value) {
		edit.putString(key, value);
		edit.commit();
	}

	// ============================================//
	public String get(String key) {
		return shared.getString(key, key);
	}

	// ============================================//
	public boolean isExist(String key) {
		return shared.contains(key);
	}

	// ============================================//
	public void remove(String key) {
		edit.remove(key);
		edit.commit();
	}

}
