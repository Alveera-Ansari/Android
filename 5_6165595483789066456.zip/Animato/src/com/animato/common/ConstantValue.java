package com.animato.common;

public interface ConstantValue {
	public boolean SHOW_LOG = true;
	public String LOG_TAG = "asd";

	public int SPLASH_TIME = 1000 * 2;
	
	//public static String SENDER_ID  = "350409956211";
	
	
	public static String SENDER_ID  = "118241936413";
	
	public String MONTHS[] = { "January", "February", "March", "April", "May", "June",
			"July", "August", "September", "October", "November", "December" };
	
	//public String EVENTS[] = { "Chamber Music", "School Orchestra", "Community Orchestra", "Professional Orchestra", "Educational Event",
	//		"Outdoor Performance", "Fiddle Concert", "Competition"};
	
	
	//public String BASE_URL = "http://nondualitycommunity.org/iphone/";
	
	
	public String KEY_REGI_ID = "key_regi_id";
	
	public String MAIN_URL = "http://animato.newsupdate.net.au/api/";
	
	public String QUOTE_URL = "quoteoftheday.php";
	public String COMMENT_URL = "comments.php";
	
	public String REGISTER_GCM_URL = "register.php";
	
	public String COUNTRY_URL = "country.php";
	
	public String BOOK_URL = "books.php";
	public String VEDIOS_URL = "videos.php";
	
	public String EVENT_URL = "eventsApi.php";
	
	public String NEWS_URL = "newsapi.php";
	
	public String EVENTS_URL = "events.php";
	
	public String EVENT_ENTERY = "event-entry.php";
	
	public String EVENT_TYPE_URL = "eventtype_list.php";
	
	//http://animato.newsupdate.net.au/api/events.php
	
	//http://animato.newsupdate.net.au/api/comments.php?comment_post_ID=4&comment_author=ajay&comment_content=this%20is%20api%20comment%20test&comment_date=2014-08-14&comment_date_gmt=2014-08-14
	
	//http://animato.newsupdate.net.au/api/books.php
	
	//http://animato.newsupdate.net.au/api/videos.php
	
	
	//http://animato.newsupdate.net.au/api/register.php?regid=12321313213213
	
	//http://animato.newsupdate.net.au/api/country.php
	
	//http://animato.newsupdate.net.au/api/events.php?country=Belgium&month=09&event_type=New
	
	//old ) http://animato.newsupdate.net.au/api/event-entry.php?start_date=2014-10-22&time=9:30&title=jai%20ho&location=chandigarh&cost=123&event_type=New%20Online%20RFP%20Tool&details=testing%20testing%20testing

	/*
	 *  http://animato.newsupdate.net.au/api/event-entry.php?start_date=2014-10-22&time=9:30&title=jai ho
	 *  &location=chandigarh&cost=123&event_type=New Online RFP Tool&details=testing testing testing
	 *  &venue=this is venue&user_name=sandy&user_phone=9211420&user_email=as@gmail.com
	 */
	
	//http://animato.newsupdate.net.au/api/eventtype_list.php
}
