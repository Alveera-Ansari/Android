package com.animato.common;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils.TruncateAt;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.wa.animato.R;

public class EditTextWithDeleteButton extends LinearLayout {
	protected EditText editText;
	protected ImageButton clearTextButton;

	public interface TextChangedListener extends TextWatcher {
	}

	TextChangedListener editTextListener = null;

	public void addTextChangedListener(TextChangedListener listener) {
		this.editTextListener = listener;
	}

	/*
	 * public EditTextWithDeleteButton(Context context) { super(context);
	 * LayoutInflater.from(context).inflate(R.layout.activity_main, this); }
	 */

	public EditTextWithDeleteButton(Context context, AttributeSet attrs) {
		super(context, attrs);
		initViews(context, attrs);
	}

	public EditTextWithDeleteButton(Context context, AttributeSet attrs,
			int defStyle) {
		this(context, attrs);
		initViews(context, attrs);
	}

	private void initViews(Context context, AttributeSet attrs) {
		
		this.setOrientation(LinearLayout.HORIZONTAL);
		//this.setPadding(3, 3, 3, 3);
		
		TypedArray a = context.getTheme().obtainStyledAttributes(attrs,
				R.styleable.EditTextWithDeleteButton, 0, 0);
		String hintText;
		int deleteButtonRes;
		try {
			// get the text and colors specified using the names in attrs.xml
			hintText = a
					.getString(R.styleable.EditTextWithDeleteButton_hintText);
			deleteButtonRes = a.getResourceId(
					R.styleable.EditTextWithDeleteButton_deleteButtonRes,
					R.drawable.text_field_clear_btn);

		} finally {
			a.recycle();
		}
		editText = createEditText(context, hintText);
		clearTextButton = createImageButton(context, deleteButtonRes);
		editText.setSingleLine(true);
		this.addView(editText);
		this.addView(clearTextButton);
		editText.addTextChangedListener(txtEntered());
		
		editText.setOnFocusChangeListener(new OnFocusChangeListener() {

			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus && editText.getText().toString().length() > 0)
					clearTextButton.setVisibility(View.VISIBLE);
				else
					clearTextButton.setVisibility(View.GONE);

			}
		});
		clearTextButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				editText.setText("");
			}
		});
	}

	public TextWatcher txtEntered() {
		return new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				if (editTextListener != null)
					editTextListener.onTextChanged(s, start, before, count);

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (editTextListener != null)
					editTextListener.afterTextChanged(s);
				if (editText.getText().toString().length() > 0)
					clearTextButton.setVisibility(View.VISIBLE);
				else
					clearTextButton.setVisibility(View.GONE);
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				if (editTextListener != null)
					editTextListener.beforeTextChanged(s, start, count, after);

			}

		};
	}

	@SuppressLint("NewApi")
	private EditText createEditText(Context context, String hintText) {
		editText = new EditText(context);
		editText.setSingleLine(true);
		editText.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
		editText.setLayoutParams(new LinearLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, 1f));
		editText.setHorizontallyScrolling(false);
		//editText.setVerticalScrollBarEnabled(true);
		editText.setGravity(Gravity.LEFT);
		//editText.setPadding(5, 3, 3, 3);
		editText.setBackgroundColor(getResources().getColor(android.R.color.transparent));
		editText.setHint(hintText);
		editText.setEllipsize(TruncateAt.END);
		editText.setFocusable(false);
		
		return editText;
	}

	private ImageButton createImageButton(Context context, int deleteButtonRes) {
		clearTextButton = new ImageButton(context);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

		params.gravity = Gravity.CENTER_VERTICAL;
		clearTextButton.setLayoutParams(params);
		clearTextButton.setPadding(2, 2, 2, 2);
		clearTextButton.setBackgroundResource(deleteButtonRes);
		clearTextButton.setVisibility(View.GONE);
		return clearTextButton;
	}

	//=================================//
	public void setText(String str) {
		// TODO Auto-generated method stub
		editText.setText(str);
	}
	
	//=================================//
		public String getText() {
			// TODO Auto-generated method stub
			return editText.getText().toString();
		}
		
		public EditText getEditText() {
			// TODO Auto-generated method stub
			return editText;
		}

}
