package com.animato.common;

import android.content.Context;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.wa.animato.R;

public class Validation {
	private Context _context;

	public Validation(Context _context) {
		this._context = _context;
	}

	//================================================================//
	public boolean checkEmpty(EditText edit, String editName) {
		String str = edit.getText().toString().trim();
		if (str.length() == 0) {
			toastMsg(editName
					+ " "
					+ _context.getString(R.string.should_not_be_empty)
							.toString());
			return true;
		}
		return false;
	}

	//================================================================//
	public boolean checkImage(ImageView iv, String imageName) {
		 if(null==iv.getDrawable())
	     {
			 toastMsg(imageName
						+ " "
						+ _context.getString(R.string.should_not_be_empty)
								.toString());
				return true;
	     }
		return false;
	}
	
	//================================================================//
	
	public boolean checkForEmail(EditText edit, String editName) {
		String str = edit.getText().toString().trim();
		if (android.util.Patterns.EMAIL_ADDRESS.matcher(str).matches()) {
			return true;
		}
		toastMsg(editName + " "
				+ _context.getString(R.string.is_not_valid).toString());
		return false;
	}
	
	//================================================================//
	private void toastMsg(String msg) {
		Toast.makeText(_context, msg, Toast.LENGTH_LONG).show();
	}
}
