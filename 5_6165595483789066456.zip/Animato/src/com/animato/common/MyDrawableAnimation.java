package com.animato.common;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;

public class MyDrawableAnimation extends AnimationDrawable {
	public Context _context;

	private int _duration = 0;

	public MyDrawableAnimation(Context _c, int frames[], int duration, boolean oneshot) {

		_context = _c;
		_duration = duration;
		for (int i = 0; i < frames.length; i++) {
			addFrame(_context.getResources().getDrawable(frames[i]), duration);
		}
		setOneShot(oneshot);
	}
	
}
