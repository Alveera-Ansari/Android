package com.animato.common;

import java.io.Serializable;

public class MyEvents implements Serializable {

	
	public static final long serialVersionUID = 1L;
	//public static String video_id = "";
	public  String event_id = "";
	public  String event_start_date = "";
	public  String event_end_date = "";
	public  String event_time = "";
	public  String event_title = "";
	public  String event_location= "";
	public  String event_cost= "";
	public  String event_details= "";


}
