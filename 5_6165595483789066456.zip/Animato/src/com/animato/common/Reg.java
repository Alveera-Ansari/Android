package com.animato.common;

public class Reg {
	
	public String id = "";
	public String regId = "";
    public String status = "";
}
